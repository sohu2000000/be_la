#include <stdio.h>
#include <stdint.h>

int cgnat_accelerate(void*id, uint8_t srcmac[6],uint8_t dstmac[6],uint32_t src_ip,
                uint16_t src_port, uint8_t protocol, uint32_t xlate_src_ip,
                uint16_t xlate_src_port, uint8_t xlate_srcmac[6],
                uint8_t xlate_dstmac[6])
{
	return 0;
}
