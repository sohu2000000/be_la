echo "
link 0 down
link 0 config 192.168.50.100 24
link 0 up
link 1 down
link 1 config 172.16.50.100 24
link 1 up

p 1 arpadd 0 192.168.50.2  52:54:00:8b:a3:ea
p 1 arpadd 1 172.16.50.202 52:54:00:e8:6e:d8
"

